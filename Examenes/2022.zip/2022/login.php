<?php

$hn = 'localhost';
$db = 'bdsimon';
$un = 'root';
$pw = '';

?>